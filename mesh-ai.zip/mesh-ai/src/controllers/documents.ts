import type { Request, Response } from 'express';

export const uploadDocument = (req: Request, res: Response): void => {
  res.status(201).json({
    success: true,
    data: {
      documentId: 'doc_001',
      filename: 'example.pdf',
      status: 'processing',
      uploadedAt: '2026-01-04T09:15:00Z',
    },
    error: null,
  });
};

export const getDocuments = (req: Request, res: Response): void => {
  res.status(200).json({
    success: true,
    data: [
      { documentId: 'doc_001', filename: 'example.pdf', status: 'ready' },
      { documentId: 'doc_002', filename: 'handbook.pdf', status: 'ready' },
    ],
    error: null,
  });
};

export const getDocumentById = (req: Request, res: Response): void => {
  res.status(200).json({
    success: true,
    data: {
      documentId: req.params.id,
      filename: 'example.pdf',
      status: 'ready',
      uploadedAt: '2026-01-04T09:15:00Z',
    },
    error: null,
  });
};

export const deleteDocument = (req: Request, res: Response): void => {
  res.status(204).send();
};
