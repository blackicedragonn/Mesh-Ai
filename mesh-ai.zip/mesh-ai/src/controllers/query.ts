import type { Request, Response } from 'express';

export const query = (req: Request, res: Response): void => {
  res.status(200).json({
    success: true,
    data: {
      question: req.body?.question ?? '',
      answer: 'This is a stubbed answer based on your documents.',
      sources: [{ documentId: 'doc_001', filename: 'example.pdf', page: 3 }],
    },
    error: null,
  });
};
