import type { Request, Response } from 'express';

export const getChats = (req: Request, res: Response): void => {
  res.status(200).json({
    success: true,
    data: [
      { chatId: 'chat_001', title: 'Chat about onboarding docs', createdAt: '2026-01-02T10:00:00Z' },
      { chatId: 'chat_002', title: 'Q3 report questions', createdAt: '2026-01-03T14:30:00Z' },
    ],
    error: null,
  });
};

export const createChat = (req: Request, res: Response): void => {
  res.status(201).json({
    success: true,
    data: {
      chatId: 'chat_003',
      title: 'New chat',
      createdAt: '2026-01-04T09:00:00Z',
    },
    error: null,
  });
};

export const getChatById = (req: Request, res: Response): void => {
  res.status(200).json({
    success: true,
    data: {
      chatId: req.params.id,
      title: 'Chat about onboarding docs',
      messages: [
        { role: 'user', content: 'What is the onboarding process?' },
        { role: 'assistant', content: 'The onboarding process starts with...' },
      ],
      createdAt: '2026-01-02T10:00:00Z',
    },
    error: null,
  });
};

export const deleteChat = (req: Request, res: Response): void => {
  res.status(204).send();
};

export const sendMessage = (req: Request, res: Response): void => {
  res.status(201).json({
    success: true,
    data: {
      chatId: req.params.id,
      message: {
        role: 'user',
        content: req.body?.content ?? '',
      },
      reply: {
        role: 'assistant',
        content: 'This is a stubbed AI reply.',
      },
    },
    error: null,
  });
};
