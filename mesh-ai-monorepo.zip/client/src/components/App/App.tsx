import { Routes, Route } from "react-router-dom";
import "./App.css"
import AppLayout from "../AppLayout/AppLayout";
import Intro from "../../pages/Intro/Intro";
import KnowledgeBase from "../../pages/KnowledgeBase/KnowledgeBase";
import Chat from "../../pages/Chat/Chat";

function App() {
  return (
    <div className="app">
      <Routes>
        {/* Intro route appears at "/" */}
        <Route path="/" element={<Intro />} />
        <Route element={<AppLayout />}>
          {/* KnowledgeBase route appears at "/knowledge" */}
          <Route path="/knowledge" element={<KnowledgeBase />} />
          {/* Chat route appears at "/chat" */}
          <Route path="/chat" element={<Chat />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;
